﻿namespace Facebook
{
    interface Page
    {
        string getHeader();
        string getOptions();
        void writeContent();
        void addContent();
    }
}